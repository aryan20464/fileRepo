"""
Copyright (c) 2017, 2026, Oracle and/or its affiliates.
Licensed under the Universal Permissive License v1.0 as shown at https://oss.oracle.com/licenses/upl.
"""
import os
import re

from java.lang import Boolean
from java.lang import System
from java.io import BufferedReader
from java.io import File
from java.io import FileInputStream
from java.io import FileOutputStream
from java.io import InputStreamReader
from java.io import PrintWriter
from java.io import IOException
from java.nio.charset import StandardCharsets

from oracle.weblogic.deploy.util import PyOrderedDict as OrderedDict

from wlsdeploy.exception import exception_helper
from wlsdeploy.logging import platform_logger
from wlsdeploy.util import dictionary_utils
from wlsdeploy.util import env_helper
from wlsdeploy.util import path_helper
from wlsdeploy.util import string_utils
from wlsdeploy.util.cla_utils import CommandLineArgUtil
import wlsdeploy.util.unicode_helper as str_helper

_class_name = "variables"
_logger = platform_logger.PlatformLogger('wlsdeploy.variables')
_file_variable_pattern = re.compile("(@@FILE:([\w.\\\/:-]+)@@)")
_property_pattern = re.compile("(@@PROP:([\\w.-]+)@@)")
_environment_pattern = re.compile("(@@ENV:([\\w.-]+)@@)")
_secret_pattern = re.compile("(@@SECRET:([\\w.-]+):([\\w.-]+)@@)")
_file_nested_variable_pattern = re.compile("(@@FILE:(@@[\w]+@@[\w.\\\/:-]+)@@)")
_variable_reference_pattern = re.compile("\\$\\{([^{}]+)\\}")

# these match a string containing ONLY a token
_property_string_pattern = re.compile("^(@@PROP:([\\w.-]+)@@)$")
_secret_string_pattern = re.compile("^(@@SECRET:([\\w.-]+):([\\w.-]+)@@)$")

# if this pattern is found, token substitution was incomplete
_unresolved_token_pattern = re.compile("(@@(PROP|FILE|ENV|SECRET):)")

SECRET_DIRS_VARIABLE = "WDT_MODEL_SECRETS_DIRS"
_secret_dir_pairs_variable = "WDT_MODEL_SECRETS_NAME_DIR_PAIRS"

_secret_token_map = None


def load_variables(file_path, allow_multiple_files=False):
    """
    Load a dictionary of variables from the specified file(s).
    :param file_path: the file from which to load properties
    :param allow_multiple_files: if True, allow a comma-separated list of variable files
    :return the dictionary of variables
    :raises VariableException if an I/O error occurs while loading the variables from the file
    """
    method_name = "load_variables"

    if allow_multiple_files:
        paths = file_path.split(CommandLineArgUtil.MODEL_FILES_SEPARATOR)
    else:
        paths = [file_path]

    variable_map = {}

    for path in paths:
        try:
            variable_map.update(string_utils.load_properties(path))
        except IOException, ioe:
            ex = exception_helper.create_variable_exception('WLSDPLY-01730', path, ioe.getLocalizedMessage(),
                                                            error=ioe)
            _logger.throwing(ex, class_name=_class_name, method_name=method_name)
            raise ex

    _resolve_variable_references(variable_map)
    return variable_map


def _resolve_variable_references(variable_map):
    """
    Resolve ${name} references in the loaded variable values.
    :param variable_map: the merged variable map
    :raises VariableException: if a variable reference is missing or cyclic
    """
    if len(variable_map) == 0:
        return

    resolved_map = {}
    for variable_name in variable_map.keys():
        _resolve_variable_reference(variable_name, variable_map, resolved_map, [])

    variable_map.update(resolved_map)


def _resolve_variable_reference(variable_name, variable_map, resolved_map, resolving_names):
    """
    Resolve a single variable value and cache the result.
    :param variable_name: the variable name to resolve
    :param variable_map: the full merged variable map
    :param resolved_map: cache of resolved variable values
    :param resolving_names: stack of variable names currently being resolved
    :return: the resolved variable value
    :raises VariableException: if a variable reference is missing or cyclic
    """
    if variable_name in resolved_map:
        return resolved_map[variable_name]

    if variable_name in resolving_names:
        cycle_start = resolving_names.index(variable_name)
        cycle_names = resolving_names[cycle_start:] + [variable_name]
        cycle_text = ' -> '.join(cycle_names)
        raise exception_helper.create_variable_exception('WLSDPLY-01762', cycle_text)

    value = variable_map[variable_name]
    if not isinstance(value, basestring) or '${' not in value:
        resolved_map[variable_name] = value
        return value

    resolving_names.append(variable_name)
    try:
        result = value
        matches = _variable_reference_pattern.findall(value)
        for referenced_name in matches:
            if referenced_name not in variable_map:
                raise exception_helper.create_variable_exception(
                    'WLSDPLY-01761', variable_name, referenced_name)
            referenced_value = _resolve_variable_reference(referenced_name, variable_map, resolved_map,
                                                           resolving_names)
            result = result.replace('${%s}' % referenced_name, referenced_value)
    finally:
        resolving_names.pop()

    resolved_map[variable_name] = result
    return result


def write_variables(program_name, variable_map, file_path, append=False):
    """
    Write variables to file while preserving order of the variables.
    :param program_name: name of the calling program
    :param variable_map: map or variable properties to write to file
    :param file_path: the file to which to write the properties
    :param append: defaults to False. Append properties to the end of file
    :raises VariableException if an error occurs while storing the variables in the file
    """
    _method_name = 'write_variables'
    _logger.entering(program_name, file_path, append, class_name=_class_name, method_name=_method_name)
    pw = None
    try:
        pw = PrintWriter(FileOutputStream(File(file_path), Boolean(append)), Boolean('true'))
        for key, value in variable_map.iteritems():
            formatted = '%s=%s' % (key, value)
            pw.println(formatted)
        pw.close()
    except IOException, ioe:
        _logger.fine('WLSDPLY-20007', program_name, file_path, ioe.getLocalizedMessage())
        ex = exception_helper.create_variable_exception('WLSDPLY-20007', program_name, file_path,
                                                        ioe.getLocalizedMessage(), error=ioe)
        _logger.throwing(ex, class_name=_class_name, method_name=_method_name)
        if pw is not None:
            pw.close()
        raise ex
    _logger.exiting(class_name=_class_name, method_name=_method_name)


def write_sorted_variables(program_name, variable_map, file_path, append=False):
    """
    Write the dictionary of variables to the specified file, in alphabetical order by key.
    :param program_name: name of tool that invoked the method which will be written to the variable properties file
    :param variable_map: the dictionary of variables
    :param file_path: the file to which to write the properties
    :param append: defaults to False. Append properties to the end of file
    :raises VariableException if an error occurs while storing the variables in the file
    """
    _method_name = 'write_sorted_variables'
    _logger.entering(program_name, file_path, append, class_name=_class_name, method_name=_method_name)

    sorted_keys = variable_map.keys()
    sorted_keys.sort()
    sorted_map = OrderedDict()
    for key in sorted_keys:
        sorted_map[key] = variable_map[key]

    write_variables(program_name, sorted_map, file_path, append)
    _logger.exiting(class_name=_class_name, method_name=_method_name)


def get_default_variable_file_name(model_context):
    """
    Generate location and file name for the variable file.
    Use the model file name and location.
    :param model_context: contains the model and archive file arguments
    :return: location and file name of variable properties file.
    """
    _method_name = 'get_default_variable_file_name'
    _logger.entering(class_name=_class_name, method_name=_method_name)

    _path_helper = path_helper.get_path_helper()
    if model_context.get_target() is not None:
        default_variable_file = \
            _path_helper.local_join(model_context.get_output_dir(),
                                    '%s_variable.properties' % model_context.get_target())
        _logger.finer('WLSDPLY-01747', model_context.get_target(), default_variable_file,
                      class_name=_class_name, method_name=_method_name)
    else:
        extract_file_name = model_context.get_model_file()
        default_variable_file = _path_helper.get_local_filename_no_ext_from_path(extract_file_name)
        _logger.finer('WLSDPLY-01748', extract_file_name, default_variable_file,
                      class_name=_class_name, method_name=_method_name)

        if default_variable_file:
            default_variable_file = \
                _path_helper.local_join(_path_helper.get_local_pathname_from_path(extract_file_name),
                                        '%s.properties' % default_variable_file)
            _logger.finer('WLSDPLY-01749', extract_file_name, default_variable_file,
                          class_name=_class_name, method_name=_method_name)

    if default_variable_file:
        _logger.finer('WLSDPLY-01736', default_variable_file, class_name=_class_name, method_name=_method_name)

    _logger.exiting(class_name=_class_name, method_name=_method_name, result=default_variable_file)
    return default_variable_file


def get_variable_names(text):
    """
    Get the list of variable names in the supplied text.
    :param text: the text to search for variables
    :return: a list of variable names
    """
    names = []
    if '@@' in text:
        matches = _property_pattern.findall(text)
        for token, key in matches:
            names.append(key)

    return names


def substitute_value(text, variables, model_context):
    """
    Perform token substitutions on a single text value.
    If errors occur during substitution, throw a single VariableException.
    :param text: the original text
    :param variables: a dictionary of variables for substitution
    :param model_context: used to resolve variables in file paths
    """
    method_name = 'substitute_value'
    error_info = {'errorCount': 0}
    result = _substitute(text, variables, model_context, error_info)
    error_count = error_info['errorCount']
    if error_count:
        ex = exception_helper.create_variable_exception("WLSDPLY-01740", error_count)
        _logger.throwing(ex, class_name=_class_name, method_name=method_name)
        raise ex
    return result


def substitute_text(text, variables, model_context):
    """
    Perform token substitutions on a single text value.
    Return a tuple with the revised text and the number of errors reported.
    :param text: the original text
    :param variables: a dictionary of variables for substitution
    :param model_context: used to resolve variables in file paths
    :return the revised text and the number of errors reported
    """
    error_info = {'errorCount': 0}
    result = _substitute(text, variables, model_context, error_info)
    return result, error_info['errorCount']


def substitute(dictionary, variables, model_context):
    """
    Substitute fields in the specified dictionary with variable values.
    If errors occur during substitution, throw a single VariableException.
    :param dictionary: the dictionary in which to substitute variables
    :param variables: a dictionary of variables for substitution
    :param model_context: used to resolve variables in file paths
    """
    method_name = '_substitute'
    error_info = {'errorCount': 0}
    _process_node(dictionary, variables, model_context, error_info)
    error_count = error_info['errorCount']
    if error_count:
        ex = exception_helper.create_variable_exception("WLSDPLY-01740", error_count)
        _logger.throwing(ex, class_name=_class_name, method_name=method_name)
        raise ex


def _process_node(nodes, variables, model_context, error_info):
    """
    Process variables in the node.
    :param nodes: the dictionary to process
    :param variables: the variables to use
    :param model_context: used to resolve variables in file paths
    :param error_info: collects information about errors encountered
    """
    # iterate over copy to avoid concurrent change for add/delete
    if isinstance(nodes, OrderedDict):
        nodes_iterator = OrderedDict(nodes)
    else:
        nodes_iterator = dict(nodes)
    for key in nodes_iterator:
        value = nodes[key]

        # if the key changes with substitution, remove old key and map value to new key
        new_key = _substitute(key, variables, model_context, error_info)
        if new_key is not key:
            del nodes[key]
            nodes[new_key] = value

        if isinstance(value, dict):
            _process_node(value, variables, model_context, error_info)

        elif isinstance(value, list):
            for member in value:
                if type(member) in [str, unicode]:
                    index = value.index(member)
                    value[index] = _substitute(member, variables, model_context, error_info, key)

        elif type(value) in [str, unicode]:
            nodes[key] = _substitute(value, variables, model_context, error_info, key)


def _substitute(text, variables, model_context, error_info, attribute_name=None):
    """
    Substitute token placeholders with their derived values.
    :param text: the text to process for token placeholders
    :param variables: the variables to use
    :param model_context: used to determine the validation method (strict, lax, etc.)
    :param error_info: collects information about errors encountered
    :return: the replaced text
    """
    method_name = '_substitute'
    validation_config = model_context.get_validate_configuration()
    problem_found = False

    # skip lookups for text with no @@
    if '@@' in text:

        # do properties first, to cover the case @@FILE:/dir/@@PROP:name@@.txt@@
        matches = _property_pattern.findall(text)
        for token, key in matches:
            # log, or throw an exception if key is not found.
            if key not in variables:
                allow_unresolved = validation_config.allow_unresolved_variable_tokens()
                if model_context.get_variable_file() is not None:
                    _report_token_issue('WLSDPLY-01732', method_name, allow_unresolved, key)
                else:
                    _report_token_issue('WLSDPLY-01734', method_name, allow_unresolved, key)

                _increment_error_count(error_info, allow_unresolved)
                problem_found = True
                continue

            value = variables[key]
            text = text.replace(token, value)

        # check environment variables before @@FILE:/dir/@@ENV:name@@.txt@@
        matches = _environment_pattern.findall(text)
        for token, key in matches:
            #
            # On Windows, environment variables are not case sensitive.  On Windows 11 anyway,
            # setting an environment variable using a name with lower-case letters will always
            # result in an environment variable name in all upper-case.
            #
            env_var_name = str_helper.to_string(key)
            is_windows = System.getProperty('os.name').startswith('Windows')
            if is_windows and not env_helper.has_env(env_var_name) and env_helper.has_env(env_var_name.upper()):
                env_var_name = env_var_name.upper()

            if not env_helper.has_env(env_var_name):
                allow_unresolved = validation_config.allow_unresolved_environment_tokens()
                _report_token_issue('WLSDPLY-01737', method_name, allow_unresolved, key)
                _increment_error_count(error_info, allow_unresolved)
                problem_found = True
                continue
            value = env_helper.getenv(env_var_name)
            text = text.replace(token, value)

        # check secret variables before @@FILE:/dir/@@SECRET:name:key@@.txt@@
        matches = _secret_pattern.findall(text)
        for token, name, key in matches:
            value = _resolve_secret_token(name, key, model_context)
            if value is None:
                # does not match, only report for non target case
                allow_unresolved = validation_config.allow_unresolved_environment_tokens()
                secret_token = name + ':' + key
                known_tokens = _list_known_secret_tokens()
                _report_token_issue('WLSDPLY-01739', method_name, allow_unresolved, secret_token, known_tokens)
                _increment_error_count(error_info, allow_unresolved)
                problem_found = True
                continue
            text = text.replace(token, value)

        matches = _file_variable_pattern.findall(text)
        for token, path in matches:
            allow_unresolved = validation_config.allow_unresolved_file_tokens()
            value = _read_value_from_file(path, allow_unresolved)
            if value is None:
                _increment_error_count(error_info, allow_unresolved)
                problem_found = True
                continue
            text = text.replace(token, value)

        # special case for @@FILE:@@ORACLE_HOME@@/dir/name.txt@@
        matches = _file_nested_variable_pattern.findall(text)
        for token, path in matches:
            path = model_context.replace_token_string(path)
            allow_unresolved = validation_config.allow_unresolved_file_tokens()
            value = _read_value_from_file(path, allow_unresolved)
            if value is None:
                _increment_error_count(error_info, allow_unresolved)
                problem_found = True
                continue
            text = text.replace(token, value)

        # if any @@TOKEN: remains in the value, log an error.
        # if previous problems were found, don't perform this check.
        matches = _unresolved_token_pattern.findall(text)
        if matches and not problem_found:
            match = matches[0]
            token = match[1]
            sample = "@@" + token + ":<name>"
            if token == "SECRET":
                sample += ":<key>"
            sample += "@@"

            # always log SEVERE, these are syntax errors in the value
            allow_unresolved = False
            if attribute_name is None:
                _report_token_issue("WLSDPLY-01745", method_name, allow_unresolved, text, sample)
            else:
                _report_token_issue("WLSDPLY-01746", method_name, allow_unresolved, attribute_name, text, sample)
                _increment_error_count(error_info, allow_unresolved)

    return text


def _increment_error_count(error_info, allow_unresolved):
    if not allow_unresolved:
        error_info['errorCount'] = error_info['errorCount'] + 1


def _read_value_from_file(file_path, allow_unresolved):
    """
    Read a single text value from the first line in the specified file.
    :param file_path: the file from which to read the value
    :param allow_unresolved: if True, log INFO instead of SEVERE for lookup failures
    :return: the text value
    :raises BundleAwareException if an error occurs while reading the value
    """
    method_name = '_read_value_from_file'

    try:
        file_reader = BufferedReader(InputStreamReader(FileInputStream(file_path), StandardCharsets.UTF_8))
        line = file_reader.readLine()
        file_reader.close()
    except IOException, e:
        _report_token_issue('WLSDPLY-01733', method_name, allow_unresolved, file_path, e.getLocalizedMessage())
        return None

    if line is None:
        line = ''

    return str_helper.to_string(line).strip()


def _resolve_secret_token(name, key, model_context):
    """
    Return the value associated with the specified secret name and key.
    If the name and key are found in the directory map, return the associated value.
    :param name: the name of the secret (a directory name or mapped name)
    :param key: the name of the file containing the secret
    :param model_context: used to determine the validation method (strict, lax, etc.)
    :return: the secret value, or None if it is not found
    """
    global _secret_token_map

    if _secret_token_map is None:
        _init_secret_token_map(model_context)

    secret_token = name + ':' + key
    return dictionary_utils.get_element(_secret_token_map, secret_token)


def _init_secret_token_map(model_context):
    """
    Initialize a global map of name/value tokens to secret values.
    The map includes secrets found below the directories specified in WDT_MODEL_SECRETS_DIRS,
    and in WDT_MODEL_SECRETS_NAME_DIR_PAIRS assignments.
    :param model_context: used to determine the validation method (strict, lax, etc.)
    """
    method_name = '_init_secret_token_map'
    global _secret_token_map

    log_method = _logger.warning
    if model_context.get_validate_configuration().allow_unresolved_secret_tokens():
        log_method = _logger.info

    _secret_token_map = dict()

    # add name/key pairs for files in sub-directories of directories in WDT_MODEL_SECRETS_DIRS.

    locations = env_helper.getenv(str_helper.to_string(SECRET_DIRS_VARIABLE))
    if locations is not None:
        for secret_dir in locations.split(","):
            if not os.path.isdir(secret_dir):
                # log at WARN or INFO, but no exception is thrown
                log_method('WLSDPLY-01738', SECRET_DIRS_VARIABLE, secret_dir, class_name=_class_name,
                           method_name=method_name)
                continue

            for subdir_name in os.listdir(secret_dir):
                subdir_path = os.path.join(secret_dir, subdir_name)
                if os.path.isdir(subdir_path):
                    _add_file_secrets_to_map(subdir_path, subdir_name, model_context)

    # add name/key pairs for files in directories assigned in WDT_MODEL_SECRETS_NAME_DIR_PAIRS.
    # these pairs will override if they were previously added as sub-directory pairs.

    dir_pairs_text = env_helper.getenv(str_helper.to_string(_secret_dir_pairs_variable))
    if dir_pairs_text is not None:
        dir_pairs = dir_pairs_text.split(',')
        for dir_pair in dir_pairs:
            result = dir_pair.split('=')
            if len(result) != 2:
                log_method('WLSDPLY-01735', _secret_dir_pairs_variable, dir_pair, class_name=_class_name,
                           method_name=method_name)
                continue

            secret_dir = result[1]
            if not os.path.isdir(secret_dir):
                log_method('WLSDPLY-01738', _secret_dir_pairs_variable, secret_dir, class_name=_class_name,
                           method_name=method_name)
                continue

            name = result[0]
            _add_file_secrets_to_map(secret_dir, name, model_context)


def _clear_secret_token_map():
    """
    Used by unit tests to force reload of map.
    """
    global _secret_token_map
    _secret_token_map = None


def _add_file_secrets_to_map(dir, name, model_context):
    """
    Add the secret from each file in the specified directory to the map.
    :param dir: the directory to be examined
    :param name: the name to be used in the map token
    :param model_context: used to determine the validation method (strict, lax, etc.)
    """
    global _secret_token_map

    for file_name in os.listdir(dir):
        file_path = os.path.join(dir, file_name)
        if os.path.isfile(file_path):
            token = name + ":" + file_name
            allow_unresolved = model_context.get_validate_configuration().allow_unresolved_secret_tokens()
            _secret_token_map[token] = _read_value_from_file(file_path, allow_unresolved)


def _list_known_secret_tokens():
    """
    Returns a string representation of the available secret name/path tokens.
    """
    global _secret_token_map

    keys = list(_secret_token_map.keys())
    keys.sort()

    ret = ''
    for key in keys:
        if ret != '':
            ret += ', '
        ret += "'" + key + "'"
    return ret


def _report_token_issue(message_key, method_name, allow_unresolved, *args):
    """
    Log a message at the level corresponding to the validation method (SEVERE for strict, INFO otherwise).
    The lax validation method can be used to verify the model without resolving tokens.
    :param message_key: the message key to be logged and used for exceptions
    :param method_name: the name of the calling method for logging
    :param allow_unresolved: if True, log INFO instead of SEVERE for lookup failures
    :param args: arguments for use in the message
    """
    log_method = _logger.severe
    if allow_unresolved:
        log_method = _logger.info

    log_method(message_key, class_name=_class_name, method_name=method_name, *args)


def substitute_key(text, variables):
    """
    Substitute any @@PROP values in the text and return.
    If the corresponding variable is not found, leave the @@PROP value in place.
    :param text: the text to be evaluated
    :param variables: the variable map
    :return: the substituted text value
    """
    if variables is not None:
        matches = _property_pattern.findall(text)
        for token, key in matches:
            if key in variables:
                value = variables[key]
                text = text.replace(token, value)

    matches = _environment_pattern.findall(text)
    for token, key in matches:
        # log, or throw an exception if key is not found.
        if not env_helper.has_env(str_helper.to_string(key)):
            continue

        value = env_helper.getenv(str_helper.to_string(key))
        text = text.replace(token, value)

    return text

def substitute_attribute(text, variables, model_context, attribute_name=None):
    """
    Return the de-tokenized value of the specified text.
    Follow the rules of the configured validation mode.
    :param text: the text to be evaluated
    :param variables: the variable map
    :param model_context: used to determine the validation mode
    :param attribute_name: the name of the attribute
    :return: the de-tokenized text value
    """
    error_info = {'errorCount': 0}
    return _substitute(text, variables, model_context, error_info, attribute_name)

def has_variables(text):
    """
    Determine if the specified text contains any variable references.
    :param text: the text to be evaluated
    :return: True if the text contains variable references, False otherwise
    """
    matches = _property_pattern.findall(text)
    return len(matches) > 0

def has_tokens(text):
    matches = _unresolved_token_pattern.findall(text)
    return len(matches) > 0

def get_variable_matches(text):
    """
    Return a list containing a tuple for each property key in the specified text.
    Each tuple contains the full expression (@@PROP:<key>@@) and just the key (<key>).
    :param text: the text to be evaluated
    :return: a list of tuples
    """
    return _property_pattern.findall(text)


def is_variable_string(value):
    """
    Return True if the value contains ONLY a variable token.
    """
    if not isinstance(value, basestring):
        return False
    return bool(_property_string_pattern.match(value))


def get_variable_string_key(value):
    """
    Return the variable key if the value contains ONLY a variable token.
    """
    if not isinstance(value, basestring):
        return None
    matches = _property_string_pattern.findall(value)
    if len(matches) > 0:
        return matches[0][1]
    return None


def is_secret_string(value):
    """
    Return True if the value contains ONLY a secret token.
    """
    if not isinstance(value, basestring):
        return False
    return bool(_secret_string_pattern.match(value))
